#include <iostream>  //sets the library for input/output stream
#include <cmath>  //sets the math library
#include <iomanip>  // sets the input/output manipulation

using namespace std;

#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
    public:
        Shape(string id, string type, string uom);
        double getArea();
        string shapeID;
        string shapeType;
        string unitofMeas;



};

#endif // SHAPE_H
