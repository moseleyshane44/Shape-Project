#include "Circle.h"  //utilize instructions from the header file to run the definitions here
#include "Shape.h"

Circle::Circle(double Radius, string id, string uom) :Shape(id, "circle", uom)//default constructor
{
    newRadius = Radius;  //sets newRadius to the Radius variable within the constructor
}

float Circle::getRadius()  // accessor function which retrieves the radius that was entered by the user
{
    return newRadius;  //returns the newRadius value for the getRadius function
}

double Circle::getArea()  // accessor that also calculates the area of the circle
{
    return ((3.1416)*(newRadius * newRadius));  //calculation for the area
}


Circle::~Circle()  //destructor function that removes the items from memory
{

}
