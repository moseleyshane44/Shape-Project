#include "Triangle.h"

Triangle::Triangle(double newBase, double newHeight, string id, string uom) :Shape(id, "triangle", uom)
{
    base = newBase;
    height = newHeight;
}

double Triange::getBase(){
    return base;
}

double Triangle::getHeight(){
    return height;
}
double Triangle::getArea(){
    return (base/2)*height;
}
Triangle::~Triangle()
{
    //dtor
}
