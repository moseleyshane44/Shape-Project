#include "Shape.h"
#include "string.h"

Shape::Shape(string id, string type, string uom)
{
    shapeID = id;
    shapeType = type;
    unitofMeas = uom;
}

Shape::~Shape()
{
    //dtor
}
double Shape::getArea(){
}
