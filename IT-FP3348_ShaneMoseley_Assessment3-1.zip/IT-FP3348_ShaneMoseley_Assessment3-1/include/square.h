#include <iostream>  //sets the library for input/output stream
#include <cmath>  //sets the math library
#include <iomanip>  // sets the input/output manipulation
#include <string>

#ifndef SQUARE_H  //if the square header is not defined
#define SQUARE_H  //define the header here

class Square :public Shape
{
    public:
        Square(double side, string id, string uom); //default constructor for the square class

        ~Square(); //destructor for the square class

        double getSide(); //accessors to retrieve data from the member variable
        double getArea();


    private: //member variables which cannot be altered
        float newSide;

};

#endif // SQUARE_H
