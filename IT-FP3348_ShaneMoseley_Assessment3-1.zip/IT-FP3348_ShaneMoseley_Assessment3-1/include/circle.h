#include <iostream>  //sets the library for input/output stream
#include <cmath>  //sets the math library
#include <iomanip>  // sets the input/output manipulation
#include <string>

#ifndef CIRCLE_H  //if the circle header is not defined
#define CIRCLE_H  //define the header here

class Circle :public Shape
{
    public:
        Circle(double Radius, string id, string uom); //default constructor for the circle class

        ~Circle(); //destructor for the circle class


        float getRadius(); //accessors to retrieve data from the member variable
        double getArea();

    private: //member variables which cannot be altered
        float newRadius;

};


#endif // CIRCLE_H
