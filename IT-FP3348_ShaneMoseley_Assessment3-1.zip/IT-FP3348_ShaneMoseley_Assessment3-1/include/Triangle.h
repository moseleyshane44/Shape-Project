#include <iostream>  //sets the library for input/output stream
#include <cmath>  //sets the math library
#include <iomanip>  // sets the input/output manipulation
#include <string>

#ifndef TRIANGLE_H
#define TRIANGLE_H


class Triangle :public Shape
{
    public:
        Triangle(double newBase, double newHeight, string id, string uom);
        virtual ~Triangle();
        double getHeight();
        double getBase();
        double getArea();

    private:
        double base;
        double height;
};

#endif // TRIANGLE_H
