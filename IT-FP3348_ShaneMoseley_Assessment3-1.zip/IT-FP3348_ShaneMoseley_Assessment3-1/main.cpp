#include <iostream>  //sets the library for input/output stream
#include <cmath>  //sets the math library
#include <iomanip>  //sets the input/output manipulation
#include <string>

#include "Shape.h"  //defines the use of the header file for the shape parent class
#include "square.h"  //defines the use of the header file for square
#include "circle.h"  //defines the use of the header file for circle
#include "Triangle.h"  //defines the use of the header file for triangle

using namespace std;

int main()
{
    float Side;  //variable to define the square's side

    cout << "Enter the length of the  square's side:";  //asks the user to input the side of the square
    cin >> Side;  //user inputs the side into the side variable

    Square square_1(Side, "square_1", "cm");  //names the holder for square as square_1


    cout << "The length of the side is:" << square_1.getSide() << "cm" << endl;  // retrieve & output to the user displaying the side data they have already entered
    cout << "The area of the square is:" << square_1.getArea()  << "cm" << endl;  //retrieve & output the area that was calculated for the user


    float Radius;  //variable to define the circle's radius

    cout << "Enter the length of the circle's radius:";  //asks the user to input the radius of the circle
    cin >> Radius;  //sets the parameter for radius. This also matches the data to the private member variable

    Circle circle_1(Radius, "circle_1", "cm");//names the holder for circle as circle_1

    cout << "The length of the radius is:" << circle_1.getRadius() << "cm" << endl;  // retrieve & output to the user displaying the side data they have already entered
    cout << "The area of the circle is:" << circle_1.getArea() << "cm" << endl;  //retrieve & output the area that was calculated for the user

    float base, height;  //variable to define the triangle's height and base variables

    cout << "Enter the length of the base:";
    cin >> base;
    cout << "Enter the height:";
    cin >> height;

    Triangle triangle_1(base, height, "triangle_1", "cm");

    cout << "The length of the base is:" << triangle_1.getBase() << "cm" << endl;
    cout << "The height of the triangle is:" << triangle_1.getHeight() << "cm" << endl;


    return 0;
}
