#include "Square.h"  //utilize instructions from the header file to run the definitions here
#include "Shape.h"

Square::Square(double side, string id, string uom) :Shape(id, "square", uom) //default constructor
{
    newSide = side;  //sets newSide to the side variable within the constructor
}

double Square::getSide()  // accessor function which retrieves the side that was entered by the user
{
    return newSide;  //returns the newSide value for the getSide function
}

double Square::getArea()  // accessor that also calculates the area of the square
{
    return (newSide * newSide);  //calculation for the area
}


Square::~Square()
{  //destructor function that removes the items from memory

}
