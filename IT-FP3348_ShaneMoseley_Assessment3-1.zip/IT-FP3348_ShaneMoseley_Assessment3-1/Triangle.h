#ifndef TRIANGLE_H
#define TRIANGLE_H


class Triangle :public Shape
{
    public:
        Triangle(double newBase, double newHeight, string id, string uom);
        virtual ~Triangle();
        double getHeight();
        double getBase();

    private:
        double base;
        double height;
};

#endif // TRIANGLE_H
